% Code for our TMM paper:
% Jie Wen, Ke Yan, Zheng Zhang, Yong Xu, Junqian Wang, Lunke Fei, Bob Zhang,
% Adaptive Graph Completion Based Incomplete Multi-view Clustering [J],
% IEEE Transactions on Multimedia, 2020.
% written by Jerry (Email: jiewen_pr@126.com)
% If you used the code, please cite the above papers.
% More codes on Incomplete multi-view clustering are released at:  
% https://sites.google.com/view/jerry-wen-hit/publications
function [U,error,obj] = AGC_IMC6noise(Sor_ini,U_ini,F_ini,numInst,num_cluster,lambda1,lambda2,lambda3,max_iter,ind_folds)
 r=3;
So = Sor_ini;
Sor = Sor_ini;
C= Sor_ini;
Bor=Sor_ini;
U = U_ini;
F = F_ini;
Y1=cell(1,length(Sor));
for i=1:length(Sor)
    Y1{1,i}=zeros(numInst,numInst);
end
% Y2=Y1;
E=Y1;
M=E;
% F=Y1;
mu=1;
% gammaoverlambda=lambda3/2*lambda1;

% % -------- ���� Sr ��ʼ����ʾϵ������A ---------- %
% A = rand(length(Sor),length(Sor));   % ��ʼ�������ӽǵ��ع�ϡ��Ȩ��Ϊ1
% A = A-diag(diag(A)); % ȥ���Ա�ʾ��Ӱ��
% for m = 1:length(Sor)
%     indx = [1:length(Sor)];
%     indx(m) = [];
%     A(indx',m) = (ProjSimplex(A(indx',m)'))'; % ��A��ÿһ�а����к͹�һ��
% end
alpha = ones(length(Sor),1)/length(Sor);%��ʼ��alpha ÿ���ӽǵ�alphaһ��
alpha_r = alpha.^r;
wei=alpha;
for iter = 1:max_iter
%     if iter == 1
%         Sor = Sor_ini;
%     end
     % ---------------- U ------------- %
    FFF = 0;
    for iv = 1:length(Sor)
        FFF = FFF+alpha_r(iv)*(F{iv}*F{iv}');
    end
    FFF(isnan(FFF))=0;
    FFF(isinf(FFF))=1e5;
    try
        [V,D] = eig(FFF);
    catch ME
        if (strcmpi(ME.identifier,'MATLAB:eig:NoConvergence'))
            [V,D] = eig(FFF, eye(size(FFF)));
        else
            rethrow(ME);
        end
    end  
    [D_sort, ind] = sort(diag(D),'descend');
    U = V(:, ind(1:num_cluster));  
   
    FFF = 0;
    % ---------------- F��i�� ------------- %
    for iv = 1:length(Sor)
%         Sor1{iv}=Sor{iv}-E{iv};
        WW = (abs(Sor{iv})+abs(Sor{iv}'))*0.5;
        LL = diag(sum(WW))-WW;
        MM =U*U'-lambda1*LL;
        MM(isnan(MM))=0;
        MM(isinf(MM))=1e5;
        try
            [V,D] = eig(MM);
        catch ME
            if (strcmpi(ME.identifier,'MATLAB:eig:NoConvergence'))
                [V,D] = eig(MM, eye(size(MM)));
            else
                rethrow(ME);
            end
        end  
        [D_sort, ind] = sort(diag(D),'descend');
        F{iv} = V(:, ind(1:num_cluster));
        clear MM V D WW D_sort ind
      
    end
    
    % ---------------- M---------------- %
      FFF1=0;
%       VVV1=0;
     for iv = 1:length(Sor)
%         W = ones(numInst,numInst);
%         ind_0 = find(ind_folds(:,iv) == 0);  % indexes of misssing instances
%         W(:,ind_0) = 0;
%         W(ind_0,:) = 0;%��ʧ������Ӧ��graphΪ0
%         [m,n]=size(W);
%         VVV=1-W;
%         VVV1=VVV1+VVV;
           FFF1 = FFF1+((F{iv}*F{iv}'));
     end
    for iv = 1:length(Sor)
        W = ones(numInst,numInst);
        ind_0 = find(ind_folds(:,iv) == 0);  % indexes of misssing instances
        W(:,ind_0) = 0;
        W(ind_0,:) = 0;%��ʧ������Ӧ��graphΪ0
        [m,n]=size(W);
        VV=1-W;
        temp1=(1/(length(Sor)-1))*(FFF1-((F{iv}*F{iv}')));
%         temp1=U*U';
        temp2=Sor{iv}-Sor_ini{iv}+E{iv}+Y1{iv}/mu;
%         E{iv}=(mu*temp2)./(2*lambda4*W+mu);
       M{iv}=(2*lambda2*VV*temp1+mu*temp2)./(2*lambda2*VV+mu);
       M{iv}=M{iv}.*VV;
% M{iv}=(abs(M{iv})+abs(M{iv}'))/2;
%  M{iv}(M{iv}<0)=0;
%  E{iv}=(2*lambda2*(1-W)*temp1+mu*temp2)./(2*lambda2*VV+mu+2*W);
%         E{iv}=(2*lambda2*VVV1*temp1+mu*temp2)./(2*lambda2*VVV1+mu+2*W);
%         for ii=1:size(E{iv},1)
%             for jj=1:size(E{iv},2)
% %                E{iv}(ii,jj)=(W(ii,jj)*(1/(length(Sor)-1))*temp1(ii,jj)+mu*temp2(ii,jj))/(W(ii,jj)+mu);
%                E{iv}(ii,jj)=(W(ii,jj)*(1/(length(Sor)-1))*temp1(ii,jj)+mu*temp2(ii,jj))/(W(ii,jj)+mu);
%             end
%         end
        
%         E{iv}=sign(temp1).*max(temp1-W/mu,0);
    end
    
     % ---------- wei ------------- %
%      www=0;
%       for iv = 1:length(Sor)
%           W = ones(numInst,numInst);
%         ind_0 = find(ind_folds(:,iv) == 0);  % indexes of misssing instances
%         W(:,ind_0) = 0;
%         W(ind_0,:) = 0;
%         temp1=F{iv}*F{iv}';
%         temp1=temp1.*W;
%         temp2=trace(temp1'*Sor_ini{iv});
%         www=www+temp2;
%       end
%        for iv = 1:length(Sor)
%         % ------- obj reconstructed error ------------ %
%         W = ones(numInst,numInst);
%         ind_0 = find(ind_folds(:,iv) == 0);  % indexes of misssing instances
%         W(:,ind_0) = 0;
%         W(ind_0,:) = 0;
%         temp1=F{iv}*F{iv}';
%         temp1=temp1.*W;
%         temp2=trace(temp1'*Sor_ini{iv});
%         wei(iv)=temp2/www;
%        end
    % ---------- alpha_v ------------- %
%     temp3=0;
    for iv = 1:length(Sor)
        E_21{iv}=0;
        for ii=1:size(E{iv},1)
            temp=norm(E{iv}(ii,:),2);
            E_21{iv}=E_21{iv}+abs(temp);
        end
    end
   Rec_error = zeros(1,length(Sor)); 
    for iv = 1:length(Sor)
        % ------- obj reconstructed error ------------ %
        W = ones(numInst,numInst);
        ind_0 = find(ind_folds(:,iv) == 0);  % indexes of misssing instances
        W(:,ind_0) = 0;
        W(ind_0,:) = 0;
        linshi_S = 0.5*(Sor{iv}+Sor{iv}');
        LSv = diag(sum(linshi_S))-linshi_S;
        temp3=(1/(length(Sor)-1))*(FFF1-((F{iv}*F{iv}')));
%        temp3=U*U';
        con=(Sor{iv}-Sor_ini{iv}-M{iv}+E{iv}+Y1{iv}/mu);
        con1=(mu/2)*norm(con,'fro')^2;
%         for ig=1:length(Sor)
%            temp=norm(((E{iv}-alpha_r(iv)*(F{ig}*F{ig}')).*(1-W)),'fro')^2;
%            temp3=temp3+temp;
%         end
        Rec_error(iv)= lambda1*trace(F{iv}'*LSv*F{iv})+lambda2*norm(((M{iv}-temp3).*(1-W)),'fro')^2+(num_cluster-trace(F{iv}*F{iv}'*U*U'))+lambda3*E_21{iv};
        %         Rec_error(iv)= norm(E{iv}.*W,'fro')^2+lambda1*trace(F{iv}'*LSv*F{iv})+lambda2*temp+lambda3*(num_cluster-trace(F{iv}*F{iv}'*U*U'));
    end
    clear Linshi_S LSv W 
    H = bsxfun(@power,Rec_error, 1/(1-r));     % h = h.^(1/(1-r));
    alpha = bsxfun(@rdivide,H,sum(H)); % alpha = H./sum(H);
    alpha_r = alpha.^r; 
%     clear H
   
    % ------------------ Sr{iv} ------------------ %
   
    vec_S = [];
    for iv = 1:length(Sor)
        vec_S = [vec_S,(Sor{iv}(:))];
    end
    for iv = 1:length(Sor)
        Z = L2_distance_1(F{iv}',F{iv}');
        W = ones(numInst,numInst);
        ind_0 = find(ind_folds(:,iv) == 0);  % indexes of misssing instances
        W(:,ind_0) = 0;
        W(ind_0,:) = 0;
        M_iv = Sor_ini{iv}-E{iv}+M{iv}-Y1{iv}/mu;
%         N_iv = C{iv}-Y2{iv}/mu;
        Linshi_L = ((mu)*(M_iv)-lambda1*Z)./((mu));
        Sor{iv}=Linshi_L;
        for num = 1:numInst
            indnum = [1:numInst];
            indnum(num) = []; 
            Sor{iv}(indnum',num) = (EProjSimplex_new(Linshi_L(indnum',num)'))';
        end
        clear Linshi_L m
     end
    clear vec_S 
    
   % ------------------ E{iv} ------------------ %
    for iv = 1:length(Sor)
        H_iv=Sor{iv}-Sor_ini{iv}-M{iv}+Y1{iv}/mu;
%         E{iv}=sign(-H_iv).*max(abs(-H_iv)-2*lambda3/mu);
%          E{iv}(E{iv}<0)=0;
        E{iv}= solve_l1l2(-H_iv',lambda3/mu)';
    end
    %%
%     for iv = 1:length(Sor)
%         W = ones(numInst,numInst);
%         ind_0 = find(ind_folds(:,iv) == 0);  % indexes of misssing instances
%         W(:,ind_0) = 0;
%         W(ind_0,:) = 0;
%         Sor{iv}=(lambda1* Bor{iv}+(W.^2)*So{iv})./(lambda1+W.^2);
%     end
%     
    % --------------  obj -------------- %
%      vec_S = [];
%     for iv = 1:length(Sor)
%         vec_S = [vec_S,(Sor{iv}(:))];
%     end
    for iv = 1:length(Sor)
        % ------- obj reconstructed error ------------ %
        W = ones(numInst,numInst);
        ind_0 = find(ind_folds(:,iv) == 0);  % indexes of misssing instances
        W(:,ind_0) = 0;
        W(ind_0,:) = 0;
        temp3=0;
        linshi_S = 0.5*(Sor{iv}+Sor{iv}');
        LSv = diag(sum(linshi_S))-linshi_S;
         temp3=(1/(length(Sor)-1))*(FFF1-((F{iv}*F{iv}')));
%         for ig=1:length(Sor)
%            temp=norm(((E{iv}-(F{ig}*F{ig}')).*(1-W)),'fro')^2;
%            temp3=temp3+temp;
%         end
%         temp=temp3-norm(((E{iv}-(F{iv}*F{iv}')).*(1-W)),'fro')^2;
 Rec_error(iv)= lambda1*trace(F{iv}'*LSv*F{iv})+lambda2*norm(((M{iv}-temp3).*(1-W)),'fro')^2+(num_cluster-trace(F{iv}*F{iv}'*U*U'))+lambda3*E_21{iv};
  Rec_error(iv)=alpha(iv)* Rec_error(iv);
% Rec_error(iv)= norm(E{iv}.*W,'fro')^2+lambda1*trace(F{iv}'*LSv*F{iv})+lambda2*norm(((M{iv}-temp3).*(1-W)),'fro')^2+(num_cluster-trace(F{iv}*F{iv}'*U*U'))+lambda3*E_21{iv};
%         Rec_error(iv)= sum(sum(abs(E{iv}.*W)))+lambda3*trace(U'*LSv*U)+lambda1*norm((E{iv}-(1/(length(Sor)-1))*((sum_Sor-Sor{iv}).*(1-W))),'fro')^2;
%         Stop(iv)=norm((Sor{iv}-Bor{iv}),'fro')^2;
    end
    clear W ind_0 linshi_S LSv
    for iv = 1:length(Sor)
       Y1{iv}=Y1{iv}+mu*(Sor{iv}-Sor_ini{iv}-M{iv}+E{iv});
       iter_error(iv)=norm(Sor{iv}-Sor_ini{iv}-M{iv}+E{iv},'fro');
%        Y2{iv}=Y2{iv}+mu*(Sor{iv}-C{iv});
    end
    mu=mu*1.1;
    mu=min(mu,1e8);
   obj(iter) = sum(Rec_error);
   error(iter) = sum(iter_error);
    if iter > 2 && obj(iter)<1e-6
        iter;
        break;
    end
end
end
