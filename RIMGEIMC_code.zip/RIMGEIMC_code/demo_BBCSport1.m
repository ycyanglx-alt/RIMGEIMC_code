% Code for our RIMGE_IMC paper:

clear all
clc

clear;
clc

Dataname = 'bbcsport4vbigRnSp';
percentDel = 0.1
r=3;


Foldname = 'bbcsport4vbigRnSp';
Datafold = [Foldname,'_percentDel_',num2str(percentDel),'.mat'];

lambda1  =1e-1;
lambda2  = 1;
lambda3 = 1000;
lambda4  = 1000 ;

         
load(Dataname);
load(Datafold);
ind_folds = folds{1};
truthF = truth;  
numInst = length(truthF);
numClust = length(unique(truthF));
num_view = length(X);
for iv = 1:num_view
    X1 = X{iv}';
    X1 = NormalizeFea(X1,1);
    ind_0 = find(ind_folds(:,iv) == 0);
    X1(ind_0,:) = [];   
    [m,n]=size(X1);
    Y{iv} = X1';            
    W1 = eye(size(ind_folds,1));
    W1(ind_0,:) = [];
    [m1,n1]=size(W1);
    G{iv} = W1;                                               
end
clear X X1 W1
X = Y;
clear Y      
for iv = 1:num_view
    options = []; 
    options.NeighborMode = 'KNN';
    options.k =9;
    options.WeightMode = 'HeatKernel';
    Z1 = constructW(X{iv}',options);
    Z_ini{iv} = (Z1);
    clear Z1;
    Sor{iv}=G{iv}'*Z_ini{iv}*G{iv};
end
LSv = 0;
alpha = ones(length(Sor),1)/length(Sor);
alpha_r = alpha.^r;
for iv = 1:length(Sor)
    linshi_S = 0.5*(Sor{iv}+Sor{iv}');
    LSv = LSv + (diag(sum(linshi_S))-linshi_S)*alpha_r(iv);
end
[U_ini, ~, ev]=eig1(LSv, numClust, 0);%��ʼ����U

F_ini = solveF(Z_ini,G,numClust);


max_iter = 50;
% % ---------------- ��ʼ�� U ------------- %

[U,E,M] = RIMGE(Sor,U_ini,F_ini,numInst,numClust,lambda1,lambda2,lambda3,max_iter,ind_folds);
new_F = U;

norm_mat = repmat(sqrt(sum(new_F.*new_F,2)),1,size(new_F,2));
for i = 1:size(norm_mat,1)
    if (norm_mat(i,1)==0)
        norm_mat(i,:) = 1;
    end
end

new_F = new_F./norm_mat; 

pre_labels    = kmeans(real(new_F),numClust,'emptyaction','singleton','replicates',20,'display','off');
result_cluster = ClusteringMeasure(truthF, pre_labels)*100;
ACC=result_cluster(1)
NMI=result_cluster(2)
Pur=result_cluster(3)



  


    
 